package test7;

public class SumNum {
	
	public SumNum(int num1, int num2) {
		for(int a = num1; a<=num2; a++) {
			System.out.println(a);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int num1 = Integer.parseInt(args[0]);
		int num2 = Integer.parseInt(args[1]);
		String unko = "";
		int sum = 0;
		for(int a = num1; a <= num2; a++) {
			unko += (a + "+");
			sum += a;
		}
		System.out.println(unko + "=" + sum);
	}

}
