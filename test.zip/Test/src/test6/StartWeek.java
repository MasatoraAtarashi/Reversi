package test6;

import java.util.Scanner;

public class StartWeek {
	static String[] weeks = new String[7];
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a = Integer.parseInt(args[0]);
		switch(a) {
		case 0:
			weeks[1] = "月";
			weeks[2] = "火";
			weeks[3] = "水";
			weeks[4] = "木";
			weeks[5] = "金";
			weeks[6] = "土";
			weeks[0] = "日";
			for(String week : weeks) {
				System.out.println(week);
			}
			break;
		case 1:
			weeks[0] = "月";
			weeks[1] = "火";
			weeks[2] = "水";
			weeks[3] = "木";
			weeks[4] = "金";
			weeks[5] = "土";
			weeks[6] = "日";
			for(String week : weeks) {
				System.out.println(week);
			}
			break;
		case 2:
			weeks[6] = "月";
			weeks[0] = "火";
			weeks[1] = "水";
			weeks[2] = "木";
			weeks[3] = "金";
			weeks[4] = "土";
			weeks[5] = "日";
			for(String week : weeks) {
				System.out.println(week);
			}
			break;
		case 3:
			weeks[5] = "月";
			weeks[6] = "火";
			weeks[0] = "水";
			weeks[1] = "木";
			weeks[2] = "金";
			weeks[3] = "土";
			weeks[4] = "日";
			for(String week : weeks) {
				System.out.println(week);
			}
			break;
		case 4:
			weeks[4] = "月";
			weeks[5] = "火";
			weeks[6] = "水";
			weeks[0] = "木";
			weeks[1] = "金";
			weeks[2] = "土";
			weeks[3] = "日";
			for(String week : weeks) {
				System.out.println(week);
			}
			break;
		case 5:
			weeks[3] = "月";
			weeks[4] = "火";
			weeks[5] = "水";
			weeks[6] = "木";
			weeks[0] = "金";
			weeks[1] = "土";
			weeks[2] = "日";
			for(String week : weeks) {
				System.out.println(week);
			}
			break;
		case 6:
			weeks[2] = "月";
			weeks[3] = "火";
			weeks[4] = "水";
			weeks[5] = "木";
			weeks[6] = "金";
			weeks[0] = "土";
			weeks[1] = "日";
			for(String week : weeks) {
				System.out.println(week);
			}
			break;
		}
	}

}
