package test8;

public class CalculatorImpl implements Calculator{
	public int addNumber(int num1,int num2){
		return num1 + num2;
	}
	
	public int subNumber(int num1,int num2) {
		return num1 - num2;
	}
}
