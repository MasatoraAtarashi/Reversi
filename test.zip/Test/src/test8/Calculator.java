package test8;

public interface Calculator {
	int addNumber(int num1,int num2);
    int subNumber(int num1,int num2);
}
